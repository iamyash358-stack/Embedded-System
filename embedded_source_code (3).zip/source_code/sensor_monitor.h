#ifndef SENSOR_MONITOR_H
#define SENSOR_MONITOR_H

#include <stdint.h>

void     ISR_adc_ready(int16_t raw_sample);
float    compute_moving_average(void);
void     busy_wait_ms(int ms);
uint32_t get_isr_fire_count(void);
uint32_t get_samples_dropped(void);
void     reset_stats(void);

#endif
