/* micro_bench.c
 * Isolates BUG-4 / FIX-4: measures the cost of compute_moving_average()
 * in a tight loop, after priming the buffer with real samples, to
 * quantify the O(n) rescan vs O(1) running-sum improvement in
 * isolation from thread scheduling / I/O noise.
 */
#include <stdio.h>
#include <time.h>
#include "sensor_monitor.h"

#define ITERATIONS 5000000

int main(void)
{
    reset_stats();
    for (int i = 0; i < 40; i++) {
        ISR_adc_ready((int16_t)(1900 + i));
    }

    volatile float sink = 0.0f;   /* prevent the optimizer discarding the call */
    struct timespec t0, t1;
    clock_gettime(CLOCK_MONOTONIC, &t0);
    for (long i = 0; i < ITERATIONS; i++) {
        sink = compute_moving_average();
    }
    clock_gettime(CLOCK_MONOTONIC, &t1);

    double elapsed_ms = (t1.tv_sec - t0.tv_sec) * 1000.0 +
                         (t1.tv_nsec - t0.tv_nsec) / 1e6;
    double ns_per_call = (elapsed_ms * 1e6) / ITERATIONS;

    printf("iterations=%d  total=%.2fms  avg=%.2fns/call  last_avg=%.2f\n",
           ITERATIONS, elapsed_ms, ns_per_call, sink);
    return 0;
}
