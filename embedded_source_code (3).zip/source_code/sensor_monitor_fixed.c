/* =====================================================================
 * sensor_monitor_fixed.c
 *
 * Revised, debugged and optimized version of sensor_monitor_buggy.c.
 * Each fix is annotated with the bug ID it resolves (see the buggy
 * file's header comment for the original defect list).
 *
 *   FIX-1  Shared state is now `volatile`, and the read-modify-write
 *          of the circular-buffer index / rolling sum is protected by
 *          a critical section (pthread_mutex here; on real hardware
 *          this is the direct equivalent of a short
 *          __disable_irq()/__enable_irq() pair around the update).
 *   FIX-2  Wrap-around uses modulo arithmetic
 *          (write_index = (write_index + 1) % BUFFER_SIZE), which is
 *          correct by construction -- there is no boundary value that
 *          can produce an out-of-bounds index.
 *   FIX-3  The blocking busy-wait delay is replaced with a short
 *          nanosleep-based yield, so the CPU is released back to the
 *          scheduler/other tasks instead of spinning at 100% load.
 *          On bare metal this is the equivalent of replacing a spin
 *          loop with WFI (Wait-For-Interrupt) / a tick-based
 *          scheduler.
 *   FIX-4  The moving average is now maintained incrementally: the
 *          ISR keeps a running sum, subtracting the sample being
 *          evicted and adding the new one, turning an O(n) rescan
 *          into an O(1) update -- with the division only performed
 *          when a caller actually asks for the average.
 *   FIX-5  The sample buffer is explicitly zero-initialised at
 *          start-of-day, so the first N averages are well-defined
 *          instead of being computed from indeterminate memory.
 * ===================================================================== */

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <pthread.h>
#include "sensor_monitor.h"

#define BUFFER_SIZE 256

/* FIX-1: volatile -- tells the compiler this state can change
 * asynchronously (from the ISR context) and must not be cached in a
 * register or reordered across the critical section. */
static volatile int16_t sample_buffer[BUFFER_SIZE];
static volatile int      write_index      = 0;
static volatile long     rolling_sum      = 0;   /* FIX-4 */
static volatile uint32_t isr_fire_count   = 0;
static volatile uint32_t samples_dropped  = 0;
static volatile int      buffer_primed    = 0;   /* have we filled it once? */

/* Stand-in for a short __disable_irq()/__enable_irq() critical
 * section. On the target MCU this protects at most a handful of
 * instructions, so it is safe and cheap to use here too. */
static pthread_mutex_t state_lock = PTHREAD_MUTEX_INITIALIZER;

static int initialised = 0;
static void ensure_init(void)
{
    if (!initialised) {
        memset((void *)sample_buffer, 0, sizeof(sample_buffer));  /* FIX-5 */
        initialised = 1;
    }
}

void ISR_adc_ready(int16_t raw_sample)
{
    ensure_init();
    pthread_mutex_lock(&state_lock);       /* FIX-1: critical section */

    isr_fire_count++;

    int16_t outgoing = sample_buffer[write_index];
    sample_buffer[write_index] = raw_sample;
    rolling_sum += raw_sample - outgoing;   /* FIX-4: O(1) update */

    write_index = (write_index + 1) % BUFFER_SIZE;   /* FIX-2 */
    if (write_index == 0) {
        buffer_primed = 1;
    }

    pthread_mutex_unlock(&state_lock);
}

/* FIX-4: O(1) -- just a division of the maintained running sum,
 * instead of an O(n) rescan of the whole buffer on every call. */
float compute_moving_average(void)
{
    pthread_mutex_lock(&state_lock);
    long sum = rolling_sum;
    pthread_mutex_unlock(&state_lock);
    return (float)sum / BUFFER_SIZE;
}

/* FIX-3: non-blocking, CPU-yielding wait. nanosleep() releases the
 * processor for the requested interval instead of spinning, which is
 * the host-side stand-in for putting the MCU into a low-power
 * WFI/sleep state until the next tick or interrupt. */
void busy_wait_ms(int ms)
{
    struct timespec req = { .tv_sec = ms / 1000, .tv_nsec = (ms % 1000) * 1000000L };
    nanosleep(&req, NULL);
}

uint32_t get_isr_fire_count(void)   { return isr_fire_count; }
uint32_t get_samples_dropped(void)  { return samples_dropped; }
void     reset_stats(void)
{
    pthread_mutex_lock(&state_lock);
    isr_fire_count = 0;
    samples_dropped = 0;
    write_index = 0;
    rolling_sum = 0;
    buffer_primed = 0;
    initialised = 0;
    pthread_mutex_unlock(&state_lock);
}
