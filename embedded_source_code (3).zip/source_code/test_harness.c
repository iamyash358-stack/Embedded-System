/* =====================================================================
 * test_harness.c
 *
 * Host-side simulation rig. Since no physical MCU/JTAG probe is
 * available in this environment, hardware is emulated as follows:
 *
 *   - A POSIX thread fires every SAMPLE_PERIOD_MS to emulate the
 *     ADC "conversion complete" hardware interrupt calling
 *     ISR_adc_ready().
 *   - The main thread runs the firmware's cooperative super-loop:
 *     kick watchdog -> service average -> transmit over "UART"
 *     (stdout) every TX_PERIOD_MS -> repeat, for TEST_DURATION_MS.
 *   - Deadline misses are detected by comparing the wall-clock gap
 *     between successive scheduler ticks against the expected period.
 *
 * Build (buggy):  gcc -O2 -g -fsanitize=address -pthread \
 *                     sensor_monitor_buggy.c test_harness.c -o test_buggy
 * Build (fixed):  gcc -O2 -g -fsanitize=address -pthread \
 *                     sensor_monitor_fixed.c test_harness.c -o test_fixed
 * ===================================================================== */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>
#include <math.h>
#include "sensor_monitor.h"

#define SAMPLE_PERIOD_MS   10      /* simulated ADC sample rate: 100 Hz  */
#define TX_PERIOD_MS       100     /* UART report rate: 10 Hz            */
#define TEST_DURATION_MS   3000    /* 3-second soak test                 */
#define DEADLINE_SLOP_MS   5.0     /* tolerance before counting a miss   */

static volatile int keep_running = 1;

static double now_ms(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec * 1000.0 + (double)ts.tv_nsec / 1e6;
}

/* Emulated hardware timer -> ADC-ready interrupt source */
static void *isr_timer_thread(void *arg)
{
    (void)arg;
    int16_t fake_signal = 0;
    while (keep_running) {
        /* synthesize a noisy sine wave "temperature" reading, x100 */
        static double t = 0.0;
        fake_signal = (int16_t)(2000.0 + 300.0 * sin(t) + (rand() % 21 - 10));
        t += 0.15;

        ISR_adc_ready(fake_signal);

        usleep(SAMPLE_PERIOD_MS * 1000);
    }
    return NULL;
}

int main(void)
{
    reset_stats();
    pthread_t isr_thread;
    pthread_create(&isr_thread, NULL, isr_timer_thread, NULL);

    double test_start   = now_ms();
    double last_tx       = test_start;
    double last_tick      = test_start;
    int    tx_count       = 0;
    int    deadline_misses = 0;
    double worst_jitter_ms = 0.0;
    clock_t cpu_start = clock();

    while (now_ms() - test_start < TEST_DURATION_MS) {
        double tick_start = now_ms();
        double gap = tick_start - last_tick;
        if (tx_count > 0 && gap > (SAMPLE_PERIOD_MS + DEADLINE_SLOP_MS)) {
            deadline_misses++;
            if (gap > worst_jitter_ms) worst_jitter_ms = gap;
        }
        last_tick = tick_start;

        /* "watchdog kick" -- trivial in simulation */

        if (now_ms() - last_tx >= TX_PERIOD_MS) {
            float avg = compute_moving_average();
            printf("[UART] t=%6.0fms  avg_raw=%.2f  isr_fires=%u\n",
                   now_ms() - test_start, avg, get_isr_fire_count());
            last_tx = now_ms();
            tx_count++;
        }

        /* BUG-3 manifests here: firmware calls its own blocking
         * "delay" as its scheduling primitive instead of yielding. */
        busy_wait_ms(1);
    }

    clock_t cpu_end = clock();
    keep_running = 0;
    pthread_join(isr_thread, NULL);

    double cpu_ms = 1000.0 * (double)(cpu_end - cpu_start) / CLOCKS_PER_SEC;

    printf("\n---- Run summary ----\n");
    printf("ISR fires:        %u\n", get_isr_fire_count());
    printf("UART reports:     %d\n", tx_count);
    printf("Scheduler-loop deadline misses (>%.0fms gap): %d\n", DEADLINE_SLOP_MS, deadline_misses);
    printf("Worst tick jitter: %.2f ms\n", worst_jitter_ms);
    printf("Main-thread CPU time consumed: %.1f ms (of %d ms wall)\n", cpu_ms, TEST_DURATION_MS);
    return 0;
}
