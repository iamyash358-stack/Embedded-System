/* =====================================================================
 * sensor_monitor_buggy.c
 *
 * Simulated embedded firmware: periodic ADC sampling + moving-average
 * filter + UART reporting + watchdog kick, running under a cooperative
 * "super-loop" scheduler.
 *
 * This is the ORIGINAL, UNPATCHED version submitted for review. It
 * contains several defects that are typical of real embedded C code:
 *
 *   BUG-1  Shared ISR/main-loop state is not declared volatile and is
 *          updated without a critical section -> race condition.
 *   BUG-2  Circular buffer wrap-around test uses '>' instead of '>=',
 *          producing a one-element out-of-bounds write once per lap.
 *   BUG-3  Main loop uses a blocking busy-wait delay instead of a
 *          non-blocking tick check -> missed sampling deadlines.
 *   BUG-4  Moving average is recomputed from scratch (O(n)) on every
 *          sample instead of being maintained incrementally (O(1)).
 *   BUG-5  The sample buffer is never initialised, so the first
 *          average values are computed from indeterminate memory.
 *
 * The host-side harness (test_harness.c) simulates the hardware timer
 * interrupt with a POSIX thread and drives this module for a fixed
 * test duration so the bugs can be reproduced and measured off-target.
 * ===================================================================== */

#include <stdio.h>
#include <string.h>
#include <time.h>
#include "sensor_monitor.h"

/* ---- "hardware" shared state -------------------------------------- */
#define BUFFER_SIZE 256

/* BUG-1: not volatile -- the compiler and the main loop are both free
 * to assume this never changes asynchronously, and there is no
 * critical section guarding the read-modify-write below. */
static int16_t sample_buffer[BUFFER_SIZE];
static int     write_index = 0;
static uint32_t samples_dropped = 0;
static uint32_t isr_fire_count  = 0;

/* Called from the simulated ADC-ready interrupt (see harness) */
void ISR_adc_ready(int16_t raw_sample)
{
    isr_fire_count++;

    /* BUG-2: off-by-one wrap check. Valid indices are 0..BUFFER_SIZE-1.
     * After writing index BUFFER_SIZE-1, write_index becomes
     * BUFFER_SIZE, and the guard below ("> BUFFER_SIZE" instead of the
     * correct ">= BUFFER_SIZE") is still false -- so on the NEXT call
     * we write to sample_buffer[BUFFER_SIZE], one element past the end
     * of the array. This is a one-shot out-of-bounds write every 32
     * samples, corrupting adjacent static memory, and is flagged by
     * AddressSanitizer as a global-buffer-overflow. */
    sample_buffer[write_index] = raw_sample;
    write_index++;
    if (write_index > BUFFER_SIZE) {
        write_index = 0;
    }
}

/* BUG-4: recomputes the average over the whole buffer every call
 * instead of maintaining a running sum -- O(n) work per sample
 * instead of O(1). On a resource-constrained MCU this burns cycles
 * and battery for no benefit. */
float compute_moving_average(void)
{
    long sum = 0;
    for (int i = 0; i < BUFFER_SIZE; i++) {
        sum += sample_buffer[i];   /* BUG-5: buffer never initialised */
    }
    return (float)sum / BUFFER_SIZE;
}

/* BUG-3: blocking busy-wait "delay" -- spins the CPU instead of
 * yielding, so nothing else in the super-loop (UART TX, watchdog
 * kick, other tasks) can run while this executes, and the next ADC
 * sample can arrive and be missed/late. */
void busy_wait_ms(int ms)
{
    clock_t start = clock();
    double target = (double)ms / 1000.0;
    while (((double)(clock() - start)) / CLOCKS_PER_SEC < target) {
        /* spin */
    }
}

uint32_t get_isr_fire_count(void)   { return isr_fire_count; }
uint32_t get_samples_dropped(void)  { return samples_dropped; }
void     reset_stats(void)          { isr_fire_count = 0; samples_dropped = 0; write_index = 0; }
